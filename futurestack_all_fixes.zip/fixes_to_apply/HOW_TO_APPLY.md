# FutureStack AI — All Fixes Applied

## Files to copy into your project (drag & drop / replace)

| File | Action |
|------|--------|
| src/routes/pricing.tsx | NEW file — add to project |
| src/routes/contact.tsx | REPLACE existing contact.tsx |
| src/components/Nav.tsx | REPLACE — adds Pricing to nav |
| src/components/Footer.tsx | REPLACE — adds Pricing link, fixes duplicate WhatsApp |
| src/components/LogoStrip.tsx | REPLACE — honest wordmark strip |
| public/sitemap.xml | NEW — helps Google crawl your site |
| public/robots.txt | NEW — tells crawlers what to index |
| src/routes/__root_meta_patch.ts | READ ONLY — copy the meta array into __root.tsx manually |

## One manual step — update __root.tsx meta

Open `src/routes/__root.tsx` and replace the `meta: [...]` array
inside `head: ()` with the values from `__root_meta_patch.ts`.

## One manual step — Formspree setup (contact form email backup)

1. Go to https://formspree.io → free account → New Form
2. Copy your form ID (e.g. xpwzgkab)
3. Open src/routes/contact.tsx → find FORMSPREE_ID
4. Replace "YOUR_FORMSPREE_ID" with your real ID

## One manual step — add /pricing to routeTree

TanStack Router auto-generates routeTree.gen.ts on dev server start.
Just run `bun dev` and the new /pricing route registers automatically.
