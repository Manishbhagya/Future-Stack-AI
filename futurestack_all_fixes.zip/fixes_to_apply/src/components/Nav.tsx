import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";

const links = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/work", label: "Work" },
  { to: "/pricing", label: "Pricing" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled ? "glass-strong" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8">
        <Link to="/" className="group flex items-center gap-2.5">
          <span className="relative inline-flex h-7 w-7 items-center justify-center rounded-md bg-gradient-to-br from-[oklch(0.72_0.19_252)] to-[oklch(0.66_0.24_295)] shadow-[0_0_20px_oklch(0.72_0.19_252/0.45)]">
            <span className="font-display text-sm font-bold text-white">F</span>
          </span>
          <span className="font-display text-[15px] font-semibold tracking-tight">
            FutureStack <span className="text-gradient-brand">AI</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="rounded-full px-4 py-1.5 text-[13.5px] text-muted-foreground transition-colors hover:text-foreground"
              activeProps={{
                className:
                  "rounded-full px-4 py-1.5 text-[13.5px] text-foreground bg-white/5",
              }}
              activeOptions={{ exact: l.to === "/" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden md:block">
          <Link
            to="/contact"
            className="group inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-[oklch(0.72_0.19_252)] to-[oklch(0.66_0.24_295)] px-4 py-1.5 text-[13px] font-semibold text-white shadow-[var(--shadow-glow)] transition-transform hover:scale-[1.02]"
          >
            Book a call <span aria-hidden>→</span>
          </Link>
        </div>

        <button
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
          className="md:hidden inline-flex h-9 w-9 items-center justify-center rounded-md border border-white/10 bg-white/5"
        >
          <span className="space-y-1">
            <span className="block h-px w-4 bg-white" />
            <span className="block h-px w-4 bg-white" />
            <span className="block h-px w-4 bg-white" />
          </span>
        </button>
      </div>

      {open && (
        <div className="md:hidden glass-strong border-t border-white/5 px-5 py-4">
          <div className="flex flex-col gap-1">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="rounded-xl px-4 py-2.5 text-sm text-foreground/80 hover:bg-white/[0.06] hover:text-foreground"
                activeProps={{ className: "rounded-xl px-4 py-2.5 text-sm text-foreground bg-white/[0.06]" }}
                activeOptions={{ exact: l.to === "/" }}
              >
                {l.label}
              </Link>
            ))}
            <Link
              to="/contact"
              onClick={() => setOpen(false)}
              className="mt-2 inline-flex items-center justify-center rounded-full bg-gradient-to-r from-[oklch(0.72_0.19_252)] to-[oklch(0.66_0.24_295)] px-5 py-2.5 text-sm font-semibold text-white"
            >
              Book a call →
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
