import { Link } from "@tanstack/react-router";

export function Footer() {
  return (
    <footer className="relative mt-32 border-t border-white/5">
      <div className="pointer-events-none absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-[oklch(0.72_0.19_252)]/40 to-transparent" />
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 sm:px-8 md:grid-cols-4">

        {/* Brand */}
        <div className="md:col-span-2">
          <div className="flex items-center gap-2.5">
            <span className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-gradient-to-br from-[oklch(0.72_0.19_252)] to-[oklch(0.66_0.24_295)]">
              <span className="font-display text-sm font-bold text-white">F</span>
            </span>
            <span className="font-display text-base font-semibold">
              FutureStack <span className="text-gradient-brand">AI</span>
            </span>
          </div>
          <p className="mt-4 max-w-sm text-sm text-muted-foreground">
            AI automation, intelligent agents, analytics platforms and AI-native websites — built and shipped from Gurgaon, India.
          </p>
          <p className="mt-6 font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground/70">
            Gurgaon · Bhubaneswar · Remote
          </p>
        </div>

        {/* Company links */}
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground/80">
            Company
          </h4>
          <ul className="mt-4 space-y-2 text-sm">
            <li>
              <Link to="/services" className="text-foreground/80 hover:text-foreground">
                Services
              </Link>
            </li>
            <li>
              <Link to="/work" className="text-foreground/80 hover:text-foreground">
                Work
              </Link>
            </li>
            <li>
              <Link to="/pricing" className="text-foreground/80 hover:text-foreground">
                Pricing
              </Link>
            </li>
            <li>
              <Link to="/about" className="text-foreground/80 hover:text-foreground">
                About
              </Link>
            </li>
            <li>
              <Link to="/contact" className="text-foreground/80 hover:text-foreground">
                Contact
              </Link>
            </li>
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground/80">
            Contact
          </h4>
          <ul className="mt-4 space-y-2 text-sm">
            <li>
              <a
                href="mailto:mail2manish.bhagyasagar@gmail.com"
                className="text-foreground/80 hover:text-foreground break-all"
              >
                mail2manish.bhagyasagar@gmail.com
              </a>
            </li>
            <li>
              <a
                href="https://wa.me/919348544857"
                target="_blank"
                rel="noreferrer"
                className="text-foreground/80 hover:text-foreground"
              >
                WhatsApp: +91 93485 44857
              </a>
            </li>
            <li>
              <a
                href="https://github.com/Manishbhagya"
                target="_blank"
                rel="noreferrer"
                className="text-foreground/80 hover:text-foreground"
              >
                GitHub
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/5">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-3 px-5 py-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:px-8">
          <span>© {new Date().getFullYear()} FutureStack AI. All rights reserved.</span>
          <span className="font-mono">v2.0 · built with intent · Gurgaon, India</span>
        </div>
      </div>
    </footer>
  );
}
