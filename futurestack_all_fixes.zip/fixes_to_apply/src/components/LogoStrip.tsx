// LogoStrip.tsx — Replace the entire file with this version
// Shows real client/project names as styled wordmarks with category labels.
// Remove any entry that is NOT a real client until you have genuine logos.

const clients = [
  { name: "City Looks", category: "Salon · Gurugram" },
  { name: "Indolink", category: "Logistics" },
  { name: "CarFX", category: "Auto Interiors · Delhi" },
  { name: "Picture Animator", category: "AI Media" },
  { name: "Garb & Go", category: "On-demand · Gurugram" },
  { name: "Vibe Craft", category: "Creative Studio" },
];

export function LogoStrip() {
  return (
    <section className="relative border-y border-white/5 bg-white/[0.015] py-10">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <p className="text-center font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
          Projects shipped for founders and operators across India
        </p>
        <div className="mt-7 grid grid-cols-2 items-center gap-x-6 gap-y-6 sm:grid-cols-3 lg:grid-cols-6">
          {clients.map((c) => (
            <div key={c.name} className="flex flex-col items-center gap-1 text-center group">
              <span className="font-display text-[15px] font-semibold tracking-tight text-foreground/60 transition-colors group-hover:text-foreground">
                {c.name}
              </span>
              <span className="font-mono text-[10px] uppercase tracking-[0.15em] text-muted-foreground/50">
                {c.category}
              </span>
            </div>
          ))}
        </div>

        {/* ── Upgrade note for when you get real logos ──────────────────────
        Once you have PNG/SVG logos from clients:
        1. Place them in src/assets/logos/
        2. Import and swap the <span> above with <img src={logo} alt={c.name} className="h-6 w-auto opacity-60 hover:opacity-100 transition-opacity" />
        ──────────────────────────────────────────────────────────────────── */}
      </div>
    </section>
  );
}
