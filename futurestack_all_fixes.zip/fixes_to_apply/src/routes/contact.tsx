import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { SectionLabel } from "@/components/ServicesSection";
import ogImage from "@/assets/og-futurestack.jpg";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Book an AI strategy call · FutureStack AI" },
      {
        name: "description",
        content:
          "Book a strategy call or message FutureStack AI on WhatsApp. We'll map your highest-leverage AI automation opportunities.",
      },
      { property: "og:title", content: "Contact FutureStack AI" },
      { property: "og:description", content: "Book a 30-minute AI strategy call." },
      { property: "og:image", content: ogImage },
    ],
  }),
  component: ContactPage,
});

const schema = z.object({
  name: z.string().trim().min(1, "Name required").max(80),
  email: z.string().trim().email("Valid email required").max(160),
  company: z.string().trim().max(120).optional().or(z.literal("")),
  message: z.string().trim().min(10, "Tell us a bit more").max(1500),
});

// ─── REPLACE with your real Formspree form ID ──────────────────────────────
// 1. Go to https://formspree.io → create a free account → New Form
// 2. Copy the form ID (looks like: xpwzgkab) and paste it below
const FORMSPREE_ID = "YOUR_FORMSPREE_ID";
// ────────────────────────────────────────────────────────────────────────────

async function sendToFormspree(data: {
  name: string;
  email: string;
  company?: string;
  message: string;
}) {
  if (FORMSPREE_ID === "YOUR_FORMSPREE_ID") return; // skip if not configured
  try {
    await fetch(`https://formspree.io/f/${FORMSPREE_ID}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        name: data.name,
        email: data.email,
        company: data.company || "—",
        message: data.message,
        _subject: `New enquiry from ${data.name} — FutureStack AI`,
      }),
    });
  } catch {
    // silent — WhatsApp is primary channel, email is backup
  }
}

function ContactPage() {
  const [status, setStatus] = useState<null | "ok" | "err">(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const data = {
      name: String(fd.get("name") ?? ""),
      email: String(fd.get("email") ?? ""),
      company: String(fd.get("company") ?? ""),
      message: String(fd.get("message") ?? ""),
    };

    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      for (const i of parsed.error.issues) fieldErrors[String(i.path[0])] = i.message;
      setErrors(fieldErrors);
      setStatus("err");
      return;
    }

    setErrors({});
    setLoading(true);

    // 1️⃣ Send to Formspree (email backup) — fire-and-forget, never blocks the UX
    sendToFormspree(parsed.data);

    // 2️⃣ Open WhatsApp with the message (primary channel)
    const text = [
      `Hi FutureStack AI,`,
      ``,
      `Name: ${parsed.data.name}`,
      `Email: ${parsed.data.email}`,
      `Company: ${parsed.data.company || "—"}`,
      ``,
      parsed.data.message,
    ].join("\n");

    window.open(`https://wa.me/919348544857?text=${encodeURIComponent(text)}`, "_blank");
    setStatus("ok");
    setLoading(false);
    (e.target as HTMLFormElement).reset();
  }

  return (
    <div className="pt-28">
      <section className="relative py-24">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 sm:px-8 lg:grid-cols-[1.05fr_1fr]">
          {/* Left col */}
          <div>
            <SectionLabel eyebrow="Contact" />
            <h1 className="font-display text-5xl font-semibold leading-[1.05] sm:text-6xl">
              Let's build your{" "}
              <span className="text-gradient-brand">AI infrastructure</span>.
            </h1>
            <p className="mt-6 max-w-xl text-[16px] text-muted-foreground">
              Tell us about your business, goals and the workflows you'd like to automate. We'll respond within one business day with a strategy outline.
            </p>

            <div className="mt-10 grid gap-3">
              {[
                {
                  l: "WhatsApp",
                  v: "+91 93485 44857",
                  href: "https://wa.me/919348544857",
                },
                {
                  l: "Email",
                  v: "mail2manish.bhagyasagar@gmail.com",
                  href: "mailto:mail2manish.bhagyasagar@gmail.com?subject=Project%20Inquiry%20—%20FutureStack%20AI",
                },
                {
                  l: "Strategy Call",
                  v: "Book 30 min →",
                  href: "https://wa.me/919348544857?text=I'd%20like%20to%20book%20a%20strategy%20call",
                },
              ].map((c) => (
                <a
                  key={c.l}
                  href={c.href}
                  target="_blank"
                  rel="noreferrer"
                  className="glass flex items-center justify-between rounded-xl px-5 py-4 transition-colors hover:bg-white/[0.06]"
                >
                  <span className="font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
                    {c.l}
                  </span>
                  <span className="text-sm font-semibold">{c.v}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Form */}
          <form
            onSubmit={onSubmit}
            className="glow-border rounded-2xl bg-gradient-to-b from-white/[0.04] to-white/[0.01] p-7 sm:p-9"
          >
            <div className="grid gap-5">
              <Field
                label="Your name"
                name="name"
                error={errors.name}
                placeholder="Manish Bhagyasagar"
              />
              <Field
                label="Email"
                name="email"
                type="email"
                error={errors.email}
                placeholder="you@company.com"
              />
              <Field
                label="Company (optional)"
                name="company"
                error={errors.company}
                placeholder="Acme Inc."
              />
              <div>
                <label className="mb-1.5 block font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                  Tell us about your project
                </label>
                <textarea
                  name="message"
                  rows={5}
                  maxLength={1500}
                  placeholder="What's the problem you're trying to solve?"
                  className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-[14.5px] outline-none ring-0 focus:border-[oklch(0.72_0.19_252)]/60 focus:bg-white/[0.05]"
                />
                {errors.message && (
                  <p className="mt-1 text-[12px] text-red-400">{errors.message}</p>
                )}
              </div>

              <button
                type="submit"
                disabled={loading}
                className="relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full bg-gradient-to-r from-[oklch(0.72_0.19_252)] to-[oklch(0.66_0.24_295)] px-6 py-3 text-sm font-semibold text-white shadow-[var(--shadow-glow)] transition-transform hover:scale-[1.01] disabled:opacity-60"
              >
                <span className="absolute inset-0 shine opacity-60" />
                <span className="relative">{loading ? "Sending…" : "Send message →"}</span>
              </button>

              {status === "ok" && (
                <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3">
                  <p className="text-[13px] font-medium text-emerald-400">
                    ✓ Opening WhatsApp with your message…
                  </p>
                  <p className="mt-0.5 text-[12px] text-emerald-400/70">
                    We also received a copy by email. We'll reply within 1 business day.
                  </p>
                </div>
              )}

              {status === "err" && Object.keys(errors).length > 0 && (
                <p className="text-[12.5px] text-red-400">
                  Please fix the errors above and try again.
                </p>
              )}
            </div>
          </form>
        </div>

        {/* Calendly */}
        <div className="mx-auto mt-20 max-w-7xl px-5 sm:px-8">
          <SectionLabel eyebrow="Or book directly" />
          <h2 className="font-display text-3xl font-semibold sm:text-4xl">
            Pick a time on{" "}
            <span className="text-gradient-brand">Calendly</span>.
          </h2>
          <p className="mt-3 max-w-xl text-[15px] text-muted-foreground">
            30-minute strategy call — we'll map your highest-leverage AI automation opportunities, live.
          </p>
          <div className="glow-border mt-8 overflow-hidden rounded-2xl bg-white/[0.02]">
            <iframe
              src="https://calendly.com/futurestack-ai/30min?hide_gdpr_banner=1&background_color=0a0b14&text_color=ffffff&primary_color=8b5cf6"
              title="Book a call with FutureStack AI"
              className="block h-[760px] w-full border-0"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </div>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
  error,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  error?: string;
}) {
  return (
    <div>
      <label className="mb-1.5 block font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
        {label}
      </label>
      <input
        name={name}
        type={type}
        placeholder={placeholder}
        maxLength={type === "email" ? 160 : 120}
        className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-[14.5px] outline-none focus:border-[oklch(0.72_0.19_252)]/60 focus:bg-white/[0.05]"
      />
      {error && <p className="mt-1 text-[12px] text-red-400">{error}</p>}
    </div>
  );
}
