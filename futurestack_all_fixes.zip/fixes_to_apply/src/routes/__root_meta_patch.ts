// ─── REPLACE THE head() meta array in src/routes/__root.tsx ─────────────────
// Find the head: () => ({ meta: [...] }) block and swap in the values below.
// Only the meta array changes — everything else in __root.tsx stays the same.

const updatedMeta = [
  { charSet: "utf-8" },
  { name: "viewport", content: "width=device-width, initial-scale=1" },

  // ✅ Fixed: includes "Gurgaon" and "India" for local SEO
  {
    title:
      "FutureStack AI | AI Automation & Web Development — Gurgaon, India",
  },
  {
    name: "description",
    content:
      "FutureStack AI builds AI automation systems, intelligent agents, data dashboards and AI-native websites for startups and SMBs across Gurgaon, NCR and India. Websites delivered in 48 hours from ₹4,999.",
  },

  // Keywords (still read by Bing, helps structure)
  {
    name: "keywords",
    content:
      "AI automation Gurgaon, web developer Gurgaon, WhatsApp chatbot India, AI agent India, Power BI dashboard SMB, website developer Odisha, FutureStack AI",
  },

  // Open Graph
  {
    property: "og:title",
    content: "FutureStack AI — AI Automation & Web Development, Gurgaon India",
  },
  {
    property: "og:description",
    content:
      "We design AI systems, automation workflows and analytics platforms for ambitious SMBs and startups across India.",
  },
  { property: "og:type", content: "website" },
  { property: "og:url", content: "https://futurestack.ai" },
  { property: "og:locale", content: "en_IN" },

  // Twitter
  { name: "twitter:card", content: "summary_large_image" },
  { name: "twitter:title", content: "FutureStack AI | AI Automation — Gurgaon, India" },
  {
    name: "twitter:description",
    content: "AI agents, automation workflows and websites — built and shipped from Gurgaon.",
  },

  // Technical
  { name: "author", content: "FutureStack AI" },
  { name: "theme-color", content: "#0a0b14" },
  { name: "robots", content: "index, follow" },
  { name: "geo.region", content: "IN-HR" },         // Haryana
  { name: "geo.placename", content: "Gurugram" },
  { name: "geo.position", content: "28.4595;77.0266" },
  { name: "ICBM", content: "28.4595, 77.0266" },
];

export default updatedMeta;

/*
HOW TO APPLY:
─────────────────────────────────────────────────────────────────
1. Open src/routes/__root.tsx
2. Find the `head: () => ({` function
3. Replace the `meta: [...]` array contents with the updatedMeta
   values above (exclude the outer const/export lines — just the
   array items inside meta: [...])
─────────────────────────────────────────────────────────────────
*/
