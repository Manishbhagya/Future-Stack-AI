import { createFileRoute, Link } from "@tanstack/react-router";
import { SectionLabel } from "@/components/ServicesSection";
import ogImage from "@/assets/og-futurestack.jpg";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — FutureStack AI | AI Automation & Websites from ₹4,999" },
      {
        name: "description",
        content:
          "Transparent pricing for AI automation, websites and data dashboards. Starting from ₹4,999. Based in Gurgaon, India — serving SMBs and startups across India.",
      },
      { property: "og:title", content: "Pricing — FutureStack AI" },
      { property: "og:description", content: "AI systems, websites and automation — clear pricing, no surprises." },
      { property: "og:image", content: ogImage },
    ],
  }),
  component: PricingPage,
});

const plans = [
  {
    name: "Starter",
    price: "₹4,999",
    tagline: "For small businesses going online",
    highlight: false,
    badge: null,
    deliverables: [
      "1–3 page professional website",
      "Mobile-first, responsive design",
      "WhatsApp CTA button (sticky)",
      "Google Maps + contact form",
      "Basic on-page SEO setup",
      "Delivered in 48 hours",
    ],
    cta: "Get started on WhatsApp",
    ctaHref: "https://wa.me/919348544857?text=Hi%20FutureStack%20AI%2C%20I'm%20interested%20in%20the%20Starter%20plan%20(₹4%2C999)",
  },
  {
    name: "Growth",
    price: "₹12,999",
    tagline: "For startups that need to convert",
    highlight: true,
    badge: "Most popular",
    deliverables: [
      "5–8 page AI-integrated website",
      "WhatsApp AI chatbot (basic)",
      "Lead capture + CRM integration",
      "SEO-optimised content pages",
      "Analytics dashboard setup",
      "Google Business Profile setup",
      "1 month post-launch support",
    ],
    cta: "Book a strategy call",
    ctaHref: "https://wa.me/919348544857?text=Hi%20FutureStack%20AI%2C%20I'm%20interested%20in%20the%20Growth%20plan%20(₹12%2C999)",
  },
  {
    name: "Enterprise",
    price: "Custom",
    tagline: "For operators who want AI infrastructure",
    highlight: false,
    badge: null,
    deliverables: [
      "Full AI agent development",
      "Automation workflow systems",
      "RAG-based support bots (24/7)",
      "Data dashboards + BI reporting",
      "Cloud deployment (AWS / Cloudflare)",
      "Custom integrations & APIs",
      "Dedicated support + SLA",
    ],
    cta: "Let's scope your project",
    ctaHref: "https://wa.me/919348544857?text=Hi%20FutureStack%20AI%2C%20I'd%20like%20to%20discuss%20a%20custom%20Enterprise%20project",
  },
];

const faqs = [
  {
    q: "How fast do you deliver?",
    a: "Starter sites go live in 48 hours from content handoff. Growth projects take 5–10 business days. Enterprise timelines are agreed upfront — typically 2–6 weeks.",
  },
  {
    q: "Do you work with businesses outside Gurgaon?",
    a: "Yes. We're based in Gurgaon and Bhubaneswar but work remotely with clients across India. All communication happens over WhatsApp and video call.",
  },
  {
    q: "What do I need to provide?",
    a: "Your logo, brand colours, business description and any photos you have. We handle the rest — copy, design, code and deployment.",
  },
  {
    q: "Is there a maintenance fee after launch?",
    a: "No mandatory retainer. Growth plan includes 1 month free support. After that, optional monthly maintenance starts at ₹1,499/month.",
  },
  {
    q: "Can I upgrade from Starter to Growth later?",
    a: "Yes. We build all projects on production stacks so upgrading is straightforward. You only pay the difference.",
  },
];

function PricingPage() {
  return (
    <div className="pt-28">
      {/* Hero */}
      <section className="relative py-20 sm:py-24">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 text-center">
          <SectionLabel eyebrow="Pricing" />
          <h1 className="mt-4 font-display text-[38px] font-semibold leading-[1.06] tracking-tight sm:text-6xl">
            Clear pricing.{" "}
            <span className="text-gradient-brand">No surprises.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-balance text-[15.5px] leading-relaxed text-muted-foreground sm:text-[17px]">
            Whether you need a landing page live in 48 hours or a full AI automation stack — we have a plan that fits. All prices in INR, GST extra.
          </p>
        </div>
      </section>

      {/* Plans */}
      <section className="relative pb-20">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="grid gap-5 md:grid-cols-3">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`relative flex flex-col rounded-3xl p-7 sm:p-8 ${
                  plan.highlight
                    ? "glow-border bg-gradient-to-b from-white/[0.08] to-white/[0.02] ring-1 ring-[oklch(0.72_0.19_252)]/30"
                    : "border border-white/10 bg-gradient-to-b from-white/[0.04] to-white/[0.01]"
                }`}
              >
                {plan.badge && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="inline-block rounded-full bg-gradient-to-r from-[oklch(0.72_0.19_252)] to-[oklch(0.66_0.24_295)] px-4 py-1 text-[11.5px] font-semibold uppercase tracking-[0.12em] text-white shadow-[var(--shadow-glow)]">
                      {plan.badge}
                    </span>
                  </div>
                )}

                <div>
                  <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                    {plan.name}
                  </p>
                  <div className="mt-3 flex items-end gap-1">
                    <span className="font-display text-4xl font-semibold sm:text-5xl">
                      {plan.price}
                    </span>
                    {plan.price !== "Custom" && (
                      <span className="mb-1.5 text-sm text-muted-foreground">one-time</span>
                    )}
                  </div>
                  <p className="mt-2 text-[14px] text-muted-foreground">{plan.tagline}</p>
                </div>

                <ul className="mt-7 flex-1 space-y-3">
                  {plan.deliverables.map((d) => (
                    <li key={d} className="flex items-start gap-2.5 text-[14px]">
                      <span className="mt-[6px] inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--brand)]" />
                      <span className="leading-snug text-foreground/90">{d}</span>
                    </li>
                  ))}
                </ul>

                <a
                  href={plan.ctaHref}
                  target="_blank"
                  rel="noreferrer"
                  className={`mt-8 inline-flex w-full items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition-transform hover:scale-[1.02] ${
                    plan.highlight
                      ? "bg-gradient-to-r from-[oklch(0.72_0.19_252)] to-[oklch(0.66_0.24_295)] text-white shadow-[var(--shadow-glow)]"
                      : "border border-white/15 bg-white/[0.03] hover:bg-white/[0.06]"
                  }`}
                >
                  {plan.cta} →
                </a>
              </div>
            ))}
          </div>

          <p className="mt-6 text-center text-[12.5px] text-muted-foreground/70">
            All prices exclusive of 18% GST · Payments via Razorpay, UPI, or bank transfer
          </p>
        </div>
      </section>

      {/* Compare table */}
      <section className="py-16">
        <div className="mx-auto max-w-4xl px-5 sm:px-8">
          <SectionLabel eyebrow="Compare" />
          <h2 className="font-display text-3xl font-semibold sm:text-4xl">
            What's <span className="text-gradient-brand">included</span>?
          </h2>

          <div className="mt-10 overflow-x-auto">
            <table className="w-full text-[13.5px]">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="pb-3 text-left font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground w-1/2">
                    Feature
                  </th>
                  {["Starter", "Growth", "Enterprise"].map((p) => (
                    <th key={p} className="pb-3 text-center font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                      {p}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {[
                  ["Professional website", "✓", "✓", "✓"],
                  ["Mobile responsive", "✓", "✓", "✓"],
                  ["WhatsApp CTA button", "✓", "✓", "✓"],
                  ["SEO setup", "Basic", "Full", "Advanced"],
                  ["WhatsApp AI chatbot", "—", "✓", "✓"],
                  ["Analytics dashboard", "—", "✓", "✓"],
                  ["CRM integration", "—", "✓", "✓"],
                  ["AI agent / automation", "—", "—", "✓"],
                  ["Cloud deployment", "Vercel", "Vercel", "AWS / CF"],
                  ["Post-launch support", "—", "1 month", "Custom SLA"],
                  ["Delivery time", "48 hrs", "5–10 days", "Custom"],
                ].map(([feat, ...vals]) => (
                  <tr key={feat} className="group">
                    <td className="py-3 text-foreground/80">{feat}</td>
                    {vals.map((v, i) => (
                      <td key={i} className="py-3 text-center">
                        {v === "✓" ? (
                          <span className="text-[oklch(0.7_0.18_160)]">✓</span>
                        ) : v === "—" ? (
                          <span className="text-muted-foreground/40">—</span>
                        ) : (
                          <span className="text-muted-foreground">{v}</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 pb-28">
        <div className="mx-auto max-w-3xl px-5 sm:px-8">
          <SectionLabel eyebrow="FAQ" />
          <h2 className="font-display text-3xl font-semibold sm:text-4xl">
            Common <span className="text-gradient-brand">questions</span>
          </h2>
          <div className="mt-10 space-y-4">
            {faqs.map((f) => (
              <div key={f.q} className="glow-border rounded-2xl bg-gradient-to-b from-white/[0.04] to-white/[0.01] p-6">
                <p className="font-display text-[16px] font-semibold">{f.q}</p>
                <p className="mt-2 text-[14.5px] leading-relaxed text-muted-foreground">{f.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
